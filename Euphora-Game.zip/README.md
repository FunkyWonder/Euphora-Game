# Euphora-Game
This is a game made in godot for a school project. All the code has been written in gdscript.

The game:
2D platformer named Euphora, the player has to parkour inside a castle and reach the top. 

Controls:
[Controls of game]
